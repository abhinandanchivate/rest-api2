// my server details would be available.
// models are

const express = require("express");
const connectDB = require("./src/config/dbConfig");
const rootRouter = require("./src/router/rootRouter");

connectDB();
const app = express();
const PORT = process.env.PORT || 5500;

app.use(express.json());
// to read the data from req body
app.use("/api", rootRouter);
// /api/v2
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
