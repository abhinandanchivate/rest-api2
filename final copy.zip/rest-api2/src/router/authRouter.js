/// end point
// userRouter : only user related end point mapping.

const express = require("express");
const { check, validationResult } = require("express-validator");
const tokenMiddleware = require("../middleware/tokenMiddleware");
const authMeController = require("../controllers/authController");

const authRouter = express.Router();
//  / => base end point for ur router
// [] ==> validation details
// async (req, res) => {} ==> controller function
// export the userRouter
// prerequisites for /auth/me
// controller, middleware

authRouter.get("/me", tokenMiddleware, authMeController);
module.exports = authRouter;
