const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  // authorization header
  // but here we will use custom header
  // called x-auth-token
  // 1. we have to collect the token from x-auth-token header
  const token = req.header("x-auth-token");

  // 2. check token is there or not
  if (!token) {
    return res.status(401).json({ msg: "No token, authorization denied " });
  }
  // 3. decrypt the token
  // 4. check the validity of the token
  try {
    const decoded = jwt.verify(token, "secret");
    req.user = decoded.user;
    console.log(
      "decoded values from middleware " + JSON.stringify(decoded.user)
    );
    next(); // will call the end point .
  } catch (err) {
    res.status(401).json({ msg: "token is not valid " });
  }
};
