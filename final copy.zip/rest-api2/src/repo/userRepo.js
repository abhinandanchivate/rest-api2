// this file is responsible for operations on  the user data to perform the database taks.

// save user data to database
const User = require("../models/userModel");
const saveUserData = async (userData) => {
  try {
    // save user data to database

    console.log("user data saved to database");
    userData.save();
    return userData._doc;
  } catch (error) {
    console.log(error);
  }
};

// get user data from database on the basis of user id
const getUserById = async (userId) => {
  try {
    // get user data from database

    const userData = await User.findById(userId);
    console.log("user data fetched from database" + userData);
    return userData;
  } catch (error) {
    console.log(error);
  }
};
// update user data in database
// delete user data from database
// get all user data from database
const getAllUsersData = async () => {
  try {
    const users = await User.find({});
    console.log("from repo" + JSON.stringify(users));
    return users;
  } catch (err) {
    throw err;
  }
};

// export the functions

module.exports = { saveUserData, getUserById, getAllUsersData };
