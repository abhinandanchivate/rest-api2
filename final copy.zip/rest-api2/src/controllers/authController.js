// /auth/me , get==> it should accept the token and
// should return the user details
// end point : private end point
// it has a dependecy on the middleware.
// we want to decrypt all the details and want to share it with the client ==> middleware ==> /auth/me ==> just share the result which we will get it from middleware.
const jwt = require("jsonwebtoken");
const { getUserById } = require("../repo/userRepo");
const { saveUser } = require("../services/userService");
const User = require("../models/userModel");
const authMeController = async (req, res) => {
  res.json(req.user);
};

module.exports = authMeController;
