// we will create a new controller for the user
// validation of data
// we will check if user already exists or not if exists
// we will return the failure resposne
// if not we will continue the user creation process
const jwt = require("jsonwebtoken");
const { getUserById } = require("../repo/userRepo");
const { saveUser, getAllUsers } = require("../services/userService");
const User = require("../models/userModel");
const userSaveController = async (req, res) => {
  const { email, name, password } = req.body;
  console.log({ email, name, password });
  try {
    const response = await saveUser(new User({ email, name, password }));
    // payload : will hold ur user related info in encrypted format

    const payload = {
      user: {
        id: response._id,
        email: response.email,
      },
    };

    jwt.sign(payload, "secret", { expiresIn: "1hr" }, (err, token) => {
      if (err) throw err;
      res.status(200).json({ userDetails: { ...response }, token });
    }); // to generate the token
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const userGetAllUsersController = async (req, res) => {
  const data = await getAllUsers();
  let users = "";

  res.status(200).json({ data });
};
// export
module.exports = { userSaveController, userGetAllUsersController };
