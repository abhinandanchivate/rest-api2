// service : service layer is used to handle all your BL
// mostly all 3rd party apis ==> would be handled by service layer .

const { saveUserData, getAllUsersData } = require("../repo/userRepo");

// business logic ==> would be handled by service layer
// service will have only 1 work to connect with DB

const saveUser = async (user) => {
  // it would be of type model ?
  return saveUserData(user);
};

const getUserById = async (userId) => {
  return getUserById(userId);
};
const getAllUsers = async () => {
  return getAllUsersData();
};
module.exports = { saveUser, getUserById, getAllUsers }; // export the functions so they can be used in
