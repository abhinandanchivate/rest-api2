// my server details would be available.
// models are
