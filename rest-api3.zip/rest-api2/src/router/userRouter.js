/// end point
// userRouter : only user related end point mapping.

const express = require("express");
const { check, validationResult } = require("express-validator");
const { userSaveController } = require("../controllers/userController");

const userRouter = express.Router();
//  / => base end point for ur router
// [] ==> validation details
// async (req, res) => {} ==> controller function
userRouter.post(
  "/",
  [
    check("email").isEmail(),
    check("password").isLength({ min: 6 }),
    check("name").isLength({ min: 3 }),
  ],
  async (req, res) => {
    // validation ===> succeeded ==> userSaveController
    // if not ===> send the failure message
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    await userSaveController(req, res);
  }
);
// export the userRouter
module.exports = userRouter;
