// service : service layer is used to handle all your BL
// mostly all 3rd party apis ==> would be handled by service layer .

const { saveUserData } = require("../repo/userRepo");

// business logic ==> would be handled by service layer
// service will have only 1 work to connect with DB

const saveUser = async (user) => {
  return saveUserData(user);
};

const getUserById = async (userId) => {
  return getUserById(userId);
};
module.exports = { saveUser, getUserById }; // export the functions so they can be used in
