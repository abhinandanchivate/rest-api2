// we will create a new controller for the user
// validation of data
// we will check if user already exists or not if exists
// we will return the failure resposne
// if not we will continue the user creation process

const { getUserById } = require("../repo/userRepo");
const { saveUser } = require("../services/userService");

const userSaveController = async (req, res) => {
  const { user } = req.body;
  try {
    const response = await saveUser(user);
    res.status(200).json(response);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// export
module.exports = { userSaveController };
