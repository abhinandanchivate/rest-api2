// this file is responsible for operations on  the user data to perform the database taks.

// save user data to database
export const saveUserData = async (userData) => {
  try {
    // save user data to database

    console.log("user data saved to database");
    userData.save();
  } catch (error) {
    console.log(error);
  }
};
// get user data from database on the basis of user id
export const getUserById = async (userId) => {
  try {
    // get user data from database
    const User = require("../models/userModel");
    const userData = await User.findById(userId);
    console.log("user data fetched from database" + userData);
    return userData;
  } catch (error) {
    console.log(error);
  }
};
// update user data in database
// delete user data from database
// get all user data from database

// export the functions
export { saveUserData, getUserById };
